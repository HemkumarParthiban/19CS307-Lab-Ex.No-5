# 19CS307-Lab-Ex.No-5
# Lab Exercise 5
# Date : 28-09-2022
# AIM :
To compose the HTML code to display five different images ( 2 on Crops and 2 on Machines and 1 on Fertilizer required ) :








 # Tag Description :







# Notepad HTML Code







# Browser output of the HTML file




 # Result : Thus the above equations were formatted by HTML tags as indicated and the required output was obtained.
